﻿#light

namespace Ast
open System


//http://www.w3.org/TR/css3-selectors/#w3cselgrammar

type Combinator = 
    | Descendant 
    | Child

type PseudoClass = 
    | AttrEquals of string

type SimpleSelector =
    | Class of string
    | Id of string
    | Attrib
    | Negation

type SequenceStart =
    | Universal
    | Tag of string

type SequencePrefix =
    | Universal
    | Tag of string

type Sequence = 
    | Prefix of SequencePrefix
    | Single of SequencePrefix * SimpleSelector
    | Many of SequencePrefix * SimpleSelector list

type Selector = 
    | Single of Sequence
    | Combined of Sequence * Combinator * Selector

type Block = 
    | Block of string

type Statement =
    | One of string
    | Many of Statement * string

